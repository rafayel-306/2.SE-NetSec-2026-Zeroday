package com.example.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiPromptInjectionChallengeApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiPromptInjectionChallengeApplication.class, args);
    }
}