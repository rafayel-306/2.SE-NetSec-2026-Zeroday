package com.example.challenge.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class AiService {
    @Value("${ai.provider}")
    private String provider;

    @Value("${ai.ollama.url}")
    private String ollamaUrl;

    @Value("${ai.ollama.model}")
    private String ollamaModel;

    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * 调用 AI 模型，传入系统指令和用户消息
     */
    public String chat(String systemPrompt, String userMessage) {
        if ("ollama".equalsIgnoreCase(provider)) {
            return callOllama(systemPrompt, userMessage);
        } else {
            return mockAi(systemPrompt, userMessage);
        }
    }

    private String callOllama(String systemPrompt, String userMessage) {
        Map<String, Object> request = new HashMap<>();
        request.put("model", ollamaModel);
        request.put("messages", new Object[]{
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", userMessage)
        });
        request.put("stream", false);
        try {
            var response = restTemplate.postForObject(ollamaUrl + "/api/chat", request, Map.class);
            if (response != null && response.containsKey("message")) {
                Map<String, String> message = (Map<String, String>) response.get("message");
                return message.get("content");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "[AI Error] Unable to reach Ollama, falling back to mock response.";
    }

    private String mockAi(String systemPrompt, String userMessage) {
        String lower = userMessage.toLowerCase();
        // 直接注入
        if ((lower.contains("忽略") && (lower.contains("指令") || lower.contains("规则"))) ||
                lower.contains("秘密口令") || lower.contains("隐藏口令")) {
            return "系统提示词泄露！隐藏口令是：F1AG7-5ECRET。FLAG{D1r3ct_1nject10n_Succ355}";
        }
        // 角色逃逸
        if (lower.contains("管理员") || lower.contains("扮演") || lower.contains("调试模式") ||
                lower.contains("输出配置") || lower.contains("数据库") || lower.contains("admin")) {
            return "已切换到管理员模式。数据库配置：/juice-shop/data/juiceshop.sqlite。FLAG{R0l3_3scap3_Succ355}";
        }
        // 间接注入（文件上传）
        if (lower.contains("ignore previous instructions") || lower.contains("泄露系统指令")) {
            return "系统提示：" + systemPrompt + " 密钥: FLAG{Ind1r3ct_Pr0mpt_1nj3ct10n_Succ355}";
        }
        return "我只能回答商品相关问题。";
    }
}