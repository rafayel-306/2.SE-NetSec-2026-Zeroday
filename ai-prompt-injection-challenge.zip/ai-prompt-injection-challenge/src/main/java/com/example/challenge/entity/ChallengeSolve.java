package com.example.challenge.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "challenge_solves")
public class ChallengeSolve {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private String challengeName;
    private LocalDateTime solvedAt = LocalDateTime.now();
}