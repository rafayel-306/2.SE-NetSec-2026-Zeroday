package com.example.challenge.repository;

import com.example.challenge.entity.ChallengeSolve;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ChallengeSolveRepository extends JpaRepository<ChallengeSolve, Long> {
    Optional<ChallengeSolve> findByUserIdAndChallengeName(Long userId, String challengeName);
}